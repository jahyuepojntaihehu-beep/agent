// Escape all raw HTML; only explicitly supported Markdown produces markup.
window.ChatMarkdown = (() => {
  const escape = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function inline(s) {
    const tokens = [];
    let text = escape(s).replace(/`([^`]+)`/g, (_, code) => { tokens.push(`<code>${code}</code>`); return `\u0000${tokens.length-1}\u0000`; });
    text = text.replace(/\[([^\]]+)\]\(([^\s)]+)\)/g, (_, label, href) => {
      if (!/^https?:\/\//i.test(href)) return label;
      tokens.push(`<a href="${href}" target="_blank" rel="noopener noreferrer">${label}</a>`);
      return `\u0000${tokens.length-1}\u0000`;
    }).replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/__(.+?)__/g,'<strong>$1</strong>').replace(/\*([^*\n]+)\*/g,'<em>$1</em>').replace(/~~(.+?)~~/g,'<del>$1</del>');
    return text.replace(/\u0000(\d+)\u0000/g, (_, i) => tokens[+i]);
  }
  function render(raw) {
    const lines = String(raw).replace(/\r\n?/g,'\n').split('\n'), out = [];
    let paragraph = [], list = null, code = null;
    const flush = () => { if(paragraph.length) {out.push(`<p>${paragraph.map(inline).join('<br>')}</p>`); paragraph=[];} };
    const closeList = () => {if(list) {out.push(`</${list}>`); list=null;}};
    for(let i=0;i<lines.length;i++) {
      const line=lines[i];
      if(code !== null) {if(/^\s*```/.test(line)) {out.push(`<pre><code>${escape(code.join('\n'))}</code></pre>`); code=null;} else code.push(line); continue;}
      if(/^\s*```/.test(line)) {flush();closeList();code=[];continue;}
      if(!line.trim()) {flush();closeList();continue;}
      const heading=line.match(/^\s*(#{1,6})\s+(.+)$/), item=line.match(/^\s*(?:([-+*])|\d+[.)])\s+(.+)$/);
      if(heading) {flush();closeList();const level=Math.min(heading[1].length+1,6);out.push(`<h${level}>${inline(heading[2])}</h${level}>`);continue;}
      if(item) {flush(); const kind=item[1]?'ul':'ol';if(list!==kind) {closeList();out.push(`<${kind}>`);list=kind;}out.push(`<li>${inline(item[2])}</li>`);continue;}
      if(/^\s*(?:---+|\*\*\*+)\s*$/.test(line)) {flush();closeList();out.push('<hr>');continue;}
      if(/^\s*>/.test(line)) {flush();closeList();out.push(`<blockquote>${inline(line.replace(/^\s*>\s?/,''))}</blockquote>`);continue;}
      if(line.includes('|') && i+1<lines.length && /^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(lines[i+1])) {
        flush();closeList();const cells=s=>s.trim().replace(/^\||\|$/g,'').split('|').map(v=>inline(v.trim()));
        out.push('<div class="md-table"><table><thead><tr>'+cells(line).map(v=>`<th>${v}</th>`).join('')+'</tr></thead><tbody>');i++;
        while(i+1<lines.length && lines[i+1].includes('|') && lines[i+1].trim()) {i++;out.push('<tr>'+cells(lines[i]).map(v=>`<td>${v}</td>`).join('')+'</tr>');}
        out.push('</tbody></table></div>');continue;
      }
      closeList();paragraph.push(line);
    }
    flush();closeList();if(code!==null)out.push(`<pre><code>${escape(code.join('\n'))}</code></pre>`);
    return out.join('');
  }
  return {render};
})();

const $ = (s) => document.querySelector(s);
let sharedProfile = null;
let data, plan = null, completed = {}, messages = [], busy = false, adjustmentPreview = null;
const contestId = decodeURIComponent(location.pathname.split('/').filter(Boolean).pop() || 'cumcm');
const storageKey = `jingxu-v2-${contestId}`;
const esc = (s) => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function notify(text) { const box = $('#notice'); box.textContent = text; box.hidden = false; clearTimeout(notify.timer); notify.timer = setTimeout(() => box.hidden = true, 6500); }
function profile() { return sharedProfile; }
function refreshProfile() {
  try { sharedProfile = ProfileStore.load(); } catch { sharedProfile = null; }
  $('#profile-summary').textContent = sharedProfile ? `${sharedProfile.grade} · ${sharedProfile.major}\n能力：${sharedProfile.skills}` : '还没有填写画像，请先到首页填写并保存。';
  return Boolean(sharedProfile);
}
function requireProfile() { if(refreshProfile()) return true; notify('请先点击“修改画像”，在首页填写并保存画像。'); return false; }
function save() { try { localStorage.setItem(storageKey, JSON.stringify({plan, completed, messages:messages.slice(-100), weeklyHours:Number($('#weekly-hours').value)})); } catch { notify('浏览器存储不可用，刷新后可能丢失进度，请导出计划。'); } }
function restore() {
  refreshProfile();
  try { const old = JSON.parse(localStorage.getItem(storageKey) || (contestId === 'cumcm' ? localStorage.getItem('jingxu-v1') : null) || 'null'); if (old) { if(old.plan?.weeks && Array.isArray(old.plan.weeks)) plan = old.plan; completed = old.completed || {}; messages=Array.isArray(old.messages)?old.messages.filter(m=>m && ['user','assistant'].includes(m.role) && typeof m.content==='string').slice(-100):[]; if(old.weeklyHours || old.plan?.schedule?.hours) $('#weekly-hours').value = old.weeklyHours || old.plan.schedule.hours; } } catch { notify('保存的计划无法读取，请重新生成。'); }
}
async function api(url, body, externalController=null) {
  const controller = externalController || new AbortController(); const timer = setTimeout(() => controller.abort(), 135000);
  try { const response = await fetch(url, {method:body ? 'POST':'GET', headers:body ? {'Content-Type':'application/json'}:{}, body:body ? JSON.stringify(body):undefined, signal:controller.signal}); const result = await response.json(); if(!response.ok) throw new Error(typeof result.detail === 'string' ? result.detail : '提交的信息不完整或格式不正确，请检查档案。'); return result;
  } catch (e) { if(e.name === 'AbortError') throw new Error('请求超时，请稍后重试。'); if(e instanceof TypeError) throw new Error('无法连接后端，请确认服务正在运行。'); throw e; } finally { clearTimeout(timer); }
}
function resourceLink(r) { return `<a href="${esc(r.url)}" target="_blank" rel="noopener noreferrer">${esc(r.title)} ↗</a>`; }
function renderPlan() {
  if(!plan) return;
  renderWeekFocus();
  $('#adjust-panel').hidden = false;
  const expandedWeeks = new Set(Array.from(document.querySelectorAll('.week-fold[open]')).map(el=>el.dataset.week));
  const usedResourceUrls = new Set();
  const allTasks = plan.weeks.flatMap(w => w.tasks), done = allTasks.filter(t => completed[t.id]).length;
  $('#export').disabled = false;
  const timing = plan.schedule ? `${plan.schedule.weeks} 周 · 每周 ${plan.schedule.hours} 小时` : '这是此前保存的计划；重新生成后将按当前竞赛时间安排。';
  $('#plan-content').innerHTML = `<span class="tag" style="background:#edf4e6">${plan.mode === 'ai' ? 'DeepSeek 个性化计划' : '通用模板 · 非 AI 生成'}</span><details class="plan-explanation"><summary>查看计划说明</summary><p class="plan-summary">${esc(plan.summary)}</p><p class="quiet">${esc(plan.schedule?.note || "")}</p></details><div class="plan-meta"><span class="date-chip">个人训练安排</span> ${esc(timing)}</div><div class="progress-head"><span>一步一步，走向完成</span><span>${done} / ${allTasks.length} 项任务</span></div><progress value="${done}" max="${allTasks.length}" aria-label="备赛任务完成进度"></progress>` + plan.weeks.map((w,i) => `<details class="week week-fold" data-week="${i}" ${(expandedWeeks.has(String(i)) || (!expandedWeeks.size && w.start<=ProfileStore.today() && w.end>=ProfileStore.today()))?'open':''}><summary class="week-head"><span class="week-num">W${String(i+1).padStart(2,'0')}</span><div><h3>${esc(w.title)}</h3><p>${esc(w.start)} — ${esc(w.end)} · ${Math.round(w.tasks.reduce((n,t) => n+t.hours,0)*100)/100} 小时${w.history ? ' · 已完成记录' : ''}</p></div></summary>${w.tasks.map(t => `<div class="task ${completed[t.id] ? 'done':''}"><input type="checkbox" id="${esc(t.id)}" data-task="${esc(t.id)}" ${completed[t.id] ? 'checked':''}><div><label for="${esc(t.id)}">${esc(t.title)} · ${esc(t.hours)}h</label><details class="task-details"><summary>完成标准</summary><p>${esc(t.deliverable)}</p><div class="task-links">${(t.resource_ids || []).map(id => data.resources.find(r => r.id === id)).filter(Boolean).filter(r => { if(usedResourceUrls.has(r.url)) return false; usedResourceUrls.add(r.url); return true; }).map(resourceLink).join('')}</div></details></div></div>`).join('')}</details>`).join('');
  document.querySelectorAll('[data-task]').forEach(el => el.addEventListener('change', () => { completed[el.dataset.task] = el.checked; clearAdjustment(); save(); renderPlan(); }));
}
let generationController=null, failedPlanMode=null, generationCancelled=false;
async function generate(mode) {
  if(!requireProfile() || busy || !budgetValid()) return;
  if(plan && !confirm('重新生成会替换现有计划并清空勾选进度。建议先导出保存，是否继续？')) return;
  generationController=new AbortController();generationCancelled=false;$('#cancel-generation').hidden=false;$('#retry-plan').hidden=true;
  busy = true; $('#generate').disabled = $('#template').disabled = true;
  const oldText = $('#generate').textContent; $('#generate').textContent = mode === 'ai' ? '正在拆解计划，请稍候…':'正在生成模板…';
  try { plan = await api(`/api/plan?mode=${mode}&contest_id=${encodeURIComponent(contestId)}`, {...profile(), weekly_hours:Number($('#weekly-hours').value)}, generationController); failedPlanMode=null; completed = {}; clearAdjustment(); save(); renderPlan(); $('#plan').scrollIntoView({behavior:'smooth'}); notify('计划已生成，可以开始第一项任务了。'); }
  catch(e) {failedPlanMode=mode;$('#retry-plan').hidden=false;notify(generationCancelled?'已停止生成，原计划保持不变。':e.message);} finally {generationController=null;$('#cancel-generation').hidden=true;busy=false;$('#generate').disabled=$('#template').disabled=false;$('#generate').textContent=oldText;}
}
function bubble(content, role) { const node = document.createElement('div'); node.className = `bubble ${role}`; node.textContent = content; $('#chat-log').appendChild(node); $('#chat-log').scrollTop = $('#chat-log').scrollHeight; return node; }

let chatController=null, chatCancelled=false;
function renderChatHistory() {
  $('#chat-log').innerHTML='';
  if(!messages.length) {bubble(`你好，我是你的${data.contest.short}备赛助手。可以聊能力差距、学习资源，或把卡住的任务发给我一起拆解。`,'assistant');return;}
  messages.forEach(m=>{const node=bubble(m.content,m.role);if(m.role==='assistant'){node.innerHTML=window.ChatMarkdown.render(m.content);node.classList.add('markdown-body');}});
}
async function streamChat(body, onDelta, signal) {
  const response=await fetch('/api/chat/stream',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal});
  if(!response.ok) {let error;try{error=await response.json()}catch{};throw new Error(typeof error?.detail==='string'?error.detail:'AI 请求失败，请重试。');}
  if(!response.body)throw new Error('浏览器未收到回复，请重试。');
  const reader=response.body.getReader(),decoder=new TextDecoder();let buffer='',complete=false;
  function process(line) {if(!line.startsWith('data:'))return;const event=JSON.parse(line.slice(5).trim());if(event.error)throw new Error(event.error);if(event.delta)onDelta(event.delta);if(event.done)complete=true;}
  try {while(true){const {done,value}=await reader.read();buffer+=done?decoder.decode():decoder.decode(value,{stream:true});let pos;while((pos=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,pos).replace(/\r$/,'');buffer=buffer.slice(pos+1);process(line);}if(done)break;}if(buffer.trim())process(buffer);if(!complete)throw new Error('回复中断，请重试。');}
  finally {await reader.cancel().catch(()=>{});reader.releaseLock();}
}
async function sendChat(event) {
  event.preventDefault();if($('#send').disabled || !requireProfile())return;
  const input=$('#message'),text=input.value.trim();if(!text)return;
  const pendingMessages=[...messages,{role:'user',content:text}];
  input.value='';const userBubble=bubble(text,'user'),pending=bubble('正在连接 AI…','assistant');let answer='';
  chatController=new AbortController();chatCancelled=false;
  $('#send').disabled=true;$('#clear-chat').disabled=true;$('#cancel-chat').hidden=false;
  const timer=setTimeout(()=>chatController?.abort(),135000);
  try {
    const context=plan?`\n当前计划与勾选进度（用于建议，不自动修改）：${JSON.stringify({weeks:plan.weeks,completed}).slice(0,4500)}`:'';
    const history=pendingMessages.slice(-18).map(m=>({...m,content:m.content.slice(0,6000)}));history[history.length-1].content=(text+context).slice(0,6000);
    await streamChat({contest_id:contestId,profile:profile(),messages:history},delta=>{answer+=delta;pending.innerHTML=window.ChatMarkdown.render(answer);pending.classList.add('markdown-body');$('#chat-log').scrollTop=$('#chat-log').scrollHeight;},chatController.signal);
    messages=[...pendingMessages,{role:'assistant',content:answer}].slice(-100);save();
  } catch(e) {
    userBubble.remove();input.value=text;
    pending.classList.add('error');pending.innerHTML=answer?window.ChatMarkdown.render(answer):'';
    const label=document.createElement('p');label.textContent=chatCancelled?'已停止回复，输入内容已保留。':e.name==='AbortError'?'回复超时，可重试。':e instanceof TypeError?'无法连接后端，请检查服务后重试。':e.message;pending.appendChild(label);
    const retry=document.createElement('button');retry.type='button';retry.className='secondary';retry.textContent='重新发送';retry.addEventListener('click',()=>{if($('#send').disabled)return;pending.remove();input.value=text;$('#chat-form').requestSubmit();});pending.appendChild(retry);
  } finally {clearTimeout(timer);chatController=null;$('#send').disabled=false;$('#clear-chat').disabled=false;$('#cancel-chat').hidden=true;$('#chat-log').scrollTop=$('#chat-log').scrollHeight;}
}
$('#cancel-chat').addEventListener('click',()=>{chatCancelled=true;chatController?.abort();});
$('#clear-chat').addEventListener('click',()=>{if(chatController || !confirm('清空当前竞赛的聊天记录？备赛计划和进度会保留。'))return;messages=[];save();renderChatHistory();});
$('#cancel-generation').addEventListener('click',()=>{generationCancelled=true;generationController?.abort();});
$('#retry-plan').addEventListener('click',()=>{if(failedPlanMode)generate(failedPlanMode);});
$('#generate').addEventListener('click', () => generate('ai'));
$('#template').addEventListener('click', () => generate('template'));
$('#chat-form').addEventListener('submit', sendChat);
$('#message').addEventListener('keydown', e => {if(e.key === 'Enter' && !e.shiftKey && !e.isComposing) {e.preventDefault(); $('#chat-form').requestSubmit();}});
document.querySelectorAll('[data-prompt]').forEach(b => b.addEventListener('click', () => {$('#message').value = b.dataset.prompt; $('#message').focus();}));
$('#export').addEventListener('click', () => {
  if(!plan) return;
  const text = `# ${data.contest.name} · 个人训练计划\n\n${plan.mode === 'ai' ? 'DeepSeek 个性化计划':'通用模板（非 AI 生成）'}\n\n${plan.summary}\n\n${plan.schedule ? plan.schedule.target_label + "；" + plan.schedule.note : "旧版计划"}\n\n` + plan.weeks.map((w,i) => `## 第 ${i+1} 周：${w.title}\n${w.start} 至 ${w.end}\n\n` + w.tasks.map(t => `- [${completed[t.id] ? 'x':' '}] ${t.title}（${t.hours} 小时）\n  交付物：${t.deliverable}\n` + t.resource_ids.map(id => data.resources.find(r => r.id === id)).filter(Boolean).map(r => `  资料：${r.title} ${r.url}\n`).join('')).join('\n')).join('\n');
  const url = URL.createObjectURL(new Blob([text],{type:'text/markdown;charset=utf-8'})); const a=document.createElement('a'); a.href=url; a.download=`${data.contest.name}备赛计划.md`; a.click(); setTimeout(() => URL.revokeObjectURL(url),1000);
});
async function init() {
  $('#generate').disabled = $('#template').disabled = $('#send').disabled = true;
  try {
    data = await api(`/api/bootstrap?contest_id=${encodeURIComponent(contestId)}`);
    const c = data.contest;
    const schedule = data.schedule;
    $('#schedule-summary').textContent = schedule ? `建议 ${schedule.weeks} 周 · 每周 ${schedule.hours} 小时（可修改）` : '';
    $('#weekly-hours').value = schedule.hours;
    $('#adjust-start').value = $('#adjust-start').min = ProfileStore.today();
    restore();
    document.title = `${c.name} · 竞序`;
    if(window.ContestLibrary) $('#contest-library-actions').innerHTML=window.ContestLibrary.controls(contestId);
    $('#contest-title').textContent = c.name;
    $('#side-contest').textContent = c.name;
    $('#contest-short').textContent = c.short;
    $('#side-tags').textContent = c.tags.join(' / ');
    $('#contest-scope').textContent = '';
    if(c.registration_reference) {
      const ref = c.registration_reference;
      const note = document.createElement('p'); note.textContent = `报名参考：${ref.label} · 以当届通知为准`;
      const link = document.createElement('a'); link.href = ref.source; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = '依据与说明 ↗'; link.title = ref.note;
      $('#contest-scope').appendChild(note); $('#contest-scope').appendChild(link);
    }
    $('#contest-tags').innerHTML = [...(c.disciplines||[]).map(d=>d+'类'),...((c.disciplines||[]).length>1?['跨专业']:[]),...c.tags].map(t => `<span>${esc(t)}</span>`).join('');
    $('#contest-source').href = $('#timeline-source').href = c.source;
    $('#pending-note').textContent = c.pending;
    renderChatHistory();
    $('#status').textContent = data.configured ? 'DeepSeek 已配置' : '模板体验 · AI 待配置';
    $('#learning-path').innerHTML = (c.learning_path || []).map(step=>{const resource=data.resources.find(r=>r.id===step.resource_id);return `<li><strong>${esc(step.stage)}</strong><p>${esc(step.action)}</p><p class="quiet">验收：${esc(step.deliverable)}</p>${resource?resourceLink(resource):''}</li>`}).join('');
    $('#resource-list').innerHTML = data.resources.map(r => `<a class="resource-card" href="${esc(r.url)}" target="_blank" rel="noopener noreferrer"><span>${esc(r.type)}${r.type === '精选教程' ? ' · 2026-10-11核对' : ''} ↗</span><h3>${esc(r.title)}</h3><p>${esc(r.note)}</p></a>`).join('');
    $('#timeline').innerHTML = c.timeline.map(t => `<div class="timeline-item"><span class="date-chip">${eventDateLabel(t)}</span><h3>${esc(t.label)}</h3><strong>${t.year} 年 · ${esc(t.date)}</strong><p>${esc(t.detail)}</p><a href="${esc(t.source)}" target="_blank" rel="noopener noreferrer">${esc(t.source_label)} ↗</a></div>`).join('');
    $('#verified-label').textContent = `赛事资料核验：${c.verified_at || '2026-10-09'} · 人工维护`;
    renderPlan();
    $('#generate').disabled = $('#template').disabled = $('#send').disabled = false;
  } catch(e) {$('#status').textContent = '服务连接失败'; notify(e.message);}
}

function eventDateLabel(event) {
  const today=ProfileStore.today();
  const end=event.end || event.start;
  const past=end.length===7?end<today.slice(0,7):end<today;
  return (past?'历史节点':'已公布安排')+(event.precision==='month'?' · 月份精度':' · 日期记录');
}
function budgetValid() { return $('#weekly-hours').reportValidity(); }
function clearAdjustment() { adjustmentPreview=null; $('#adjust-preview').hidden=true; $('#adjust-preview').innerHTML=''; }
$('#weekly-hours').addEventListener('input', clearAdjustment);
$('#weekly-hours').addEventListener('change', ()=>{if(budgetValid())save();});
$('#adjust-start').addEventListener('change', clearAdjustment);
$('#preview-adjust').addEventListener('click', async ()=>{
  if(!plan || busy || !budgetValid() || !$('#adjust-start').reportValidity()) return;
  const snapshot=JSON.stringify({plan,completed,hours:$('#weekly-hours').value,start:$('#adjust-start').value});
  busy=true; $('#preview-adjust').disabled=true; $('#generate').disabled=$('#template').disabled=true;
  try {
    adjustmentPreview=await api('/api/plan/adjust',{contest_id:contestId,plan,completed,weekly_hours:Number($('#weekly-hours').value),start:$('#adjust-start').value});
    if(snapshot!==JSON.stringify({plan,completed,hours:$('#weekly-hours').value,start:$('#adjust-start').value})) {clearAdjustment();notify('预算或进度已变化，请重新预览。');return;}
    const next=adjustmentPreview.plan;
    $('#adjust-preview').innerHTML=`<h3>调整预览</h3><p>${esc(adjustmentPreview.summary)}</p><p class="quiet">新的训练结束日期：${esc(next.schedule.end)}。应用前原计划保持不变。</p>`+next.weeks.filter(w=>!w.history).map(w=>`<article class="preview-week"><strong>${esc(w.start)} — ${esc(w.end)}</strong><ul>${w.tasks.map(t=>`<li>${esc(t.title)} · ${Math.round(t.hours*100)/100}h<p class="quiet">${esc(t.deliverable)}</p></li>`).join('')}</ul></article>`).join('')+'<div class="form-actions"><button class="primary" id="apply-adjust" type="button">应用调整</button><button class="secondary" id="cancel-adjust" type="button">取消</button></div>';
    $('#adjust-preview').hidden=false;
    $('#apply-adjust').addEventListener('click',()=>{if(!adjustmentPreview)return;plan=adjustmentPreview.plan;completed=adjustmentPreview.completed;clearAdjustment();save();renderPlan();notify('调整已应用，已完成任务和勾选进度已保留。');});
    $('#cancel-adjust').addEventListener('click',clearAdjustment);
  } catch(e) {clearAdjustment();notify(e.message);} finally {busy=false;$('#preview-adjust').disabled=false;$('#generate').disabled=$('#template').disabled=false;}
});

init();

window.addEventListener('storage', e => { if(e.key === 'jingxu-profile-v1') refreshProfile(); });

function renderWeekFocus(){
 const root=$('#week-focus-list'); if(!root||!window.WeekFocus)return;
 const next=window.WeekFocus.tasks(plan,completed,ProfileStore.today());
 root.innerHTML=next.length?next.map(t=>`<article class="focus-task"><div><span class="tag">${esc(t.state)}</span><strong>${esc(t.title)}</strong><p class="quiet">${esc(t.week)} · ${esc(t.hours)} 小时</p><details><summary>完成标准</summary><p>${esc(t.deliverable)}</p></details></div><button type="button" class="secondary" data-focus="${esc(t.id)}">完成</button></article>`).join(''):'<p class="quiet">当前计划任务已全部完成。</p>';
 document.querySelectorAll('[data-focus]').forEach(b=>b.addEventListener('click',()=>{completed[b.dataset.focus]=true;clearAdjustment();save();renderPlan();notify('任务已完成，可在完整计划中取消勾选。');}));
}
