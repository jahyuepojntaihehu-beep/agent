(() => {
 const KEY='jingxu-library-v1'; let catalog=[];let favorites=[];
 try{const saved=JSON.parse(localStorage.getItem(KEY)||'{}');favorites=Array.isArray(saved.favorites)?[...new Set(saved.favorites.filter(x=>typeof x==='string'))]:[];}catch{}
 const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const status=text=>{const el=document.querySelector('#library-status');if(el)el.textContent=text;};
 function save(){try{localStorage.setItem(KEY,JSON.stringify({favorites}));return true;}catch{status('无法保存，请检查浏览器存储权限。');return false;}}
 function controls(id){return `<div class="contest-actions"><button type="button" data-favorite="${esc(id)}" aria-pressed="${favorites.includes(id)}">${favorites.includes(id)?'★ 已收藏':'☆ 收藏'}</button></div>`;}
 function render(){
  document.querySelectorAll('[data-favorite]').forEach(b=>{b.textContent=favorites.includes(b.dataset.favorite)?'★ 已收藏':'☆ 收藏';b.setAttribute('aria-pressed',String(favorites.includes(b.dataset.favorite)));});
  const list=document.querySelector('#favorite-list');
  if(list)list.innerHTML=catalog.filter(c=>favorites.includes(c.id)).map(c=>`<article class="favorite-card"><a href="/competitions/${encodeURIComponent(c.id)}">${esc(c.short)}</a><p class="quiet">${esc(c.fit_reason||'')}</p>${controls(c.id)}</article>`).join('')||'<p class="quiet">收藏感兴趣的赛事，在这里快速进入。</p>';

 }
 document.addEventListener('click',e=>{
  const b=e.target.closest('button[data-favorite]');if(!b)return;
  const oldFavorites=[...favorites],id=b.dataset.favorite;
  favorites=favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id];
  if(!save()){favorites=oldFavorites;return;}
  status(favorites.includes(id)?'已收藏':'已取消收藏');render();window.dispatchEvent(new Event('contest-library-change'));
 });
 window.addEventListener('storage',e=>{if(e.key===KEY){try{const s=JSON.parse(e.newValue||'{}');favorites=Array.isArray(s.favorites)?s.favorites:[];render();window.dispatchEvent(new Event('contest-library-change'));}catch{}}});
 window.ContestLibrary={controls,isFavorite:id=>favorites.includes(id),setCatalog(items){catalog=items;render();},render};
 render();
})();
