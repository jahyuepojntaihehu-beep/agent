# 竞序 · 大学生备赛助手 MVP

首页 Part 01 是简洁的单线时间轴，按往年报名月份排序，展示北京时间当前月份起共 12 个月，只显示参考月份和可点击的竞赛名称。月份属于备赛规划参考，不是下一届确定日程；校内报名因校而异，“挑战杯”两项主体赛按交替年份展示。侧边栏保留全部 15 项竞赛入口（7 项原始赛事 + 8 项扩展赛事），不包含统计建模。

时间轴下方只填写专业、年级、能力，所有竞赛共用。点击竞赛名称进入独立子页，每项竞赛均有画像摘要、系统建议的训练安排、对应资料架、不同的训练模板、DeepSeek 对话与个性化计划接口、工时校验、任务勾选及 Markdown 导出。暂无 API Key 时可使用“先体验模板”。子页“修改画像”返回首页。

训练时间无需填写：后端优先使用未来已公布的准确报名开启日期，否则按照时间轴参考报名月份和届次周期安排。距离较远先生成近期12周；已进入参考月份则安排月内训练。每周投入按距离给出6/8/10小时建议，不代表用户承诺的可用时间。生成的日期属于个人训练安排，不是推定的官方截止日。

## 启动

需要 Python 3.10+。在项目目录执行：

```powershell
python -m venv .venv
./.venv/Scripts/python.exe -m pip install -r requirements.txt
if (-not (Test-Path .env)) { Copy-Item .env.example .env }
# 编辑 .env，填写 DEEPSEEK_API_KEY；不要把密钥放入网页或提交到 Git。
./.venv/Scripts/python.exe -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
```

浏览器打开 http://127.0.0.1:8000 。也可执行 `./start.ps1`。

`.env` 配置：

```dotenv
DEEPSEEK_API_KEY=你自己的密钥
DEEPSEEK_MODEL=deepseek-chat
```

密钥从 https://platform.deepseek.com/ 获取，只写在 `.env` 里；仓库和交付包都不含密钥，`.env.example` 是模板。模型名以自己的账户与官方文档为准：https://api-docs.deepseek.com/ 。修改后重启后端。

**不要使用推理模型（如 `deepseek-flash`）**：思维链会占满输出额度，12 周计划的 JSON 会被截断，生成计划约三次失败两次。后端已会识别截断并自动重试一次，但换成 `deepseek-chat` 才是根治，且耗时从约 39 秒降到约 12 秒。

没有密钥仍可浏览资料、生成明确标注的通用模板，但 AI 对话和个性化计划会提示未配置，不会伪装成模型回复。

## 技术与目录

- `backend/main.py`：FastAPI 后端，使用 HTTPX 调用 DeepSeek；密钥只在后端读取。
- `backend/catalog.py`：7 项原始竞赛资料、带年份和来源的节点、资源与差异化训练模板。
- `backend/catalog_expansion.py`：另外 8 项扩展竞赛；训练主题由赛项自动生成，粒度比原始 7 项粗。
- `backend/scheduling.py`：北京时间、官方日期优先、参考月份回退、近期训练周期及投入建议。
- `frontend/home.html` / `home.js`：首页单线时间轴与共享画像表单。
- `frontend/timeline.js`：以北京时间当前月份起共 12 个月排列参考报名月份，同月只展示一次；按参考周期区分两项“挑战杯”主体赛。投影月份只用于规划，不写入官方赛程。
- `frontend/profile-store.js`：共享画像读写和旧版画像迁移。
- `/competitions/{contest_id}`：独立竞赛备赛页面，直接访问或刷新均可。
- `frontend/`：原生 HTML / CSS / JavaScript，无需 Node.js 或外部 CDN。前后端通过 JSON API 通信，后续可独立替换成 React。
- `GET /api/contests`：全部 15 项竞赛和带来源的时间节点。
- `GET /api/bootstrap?contest_id=innovation`：指定竞赛的配置状态、资料和资源；默认 `cumcm`。
- `POST /api/chat`：请求包含 `contest_id`、`profile` 和 `messages`，只注入当前竞赛上下文。
- `POST /api/plan?mode=ai|template&contest_id=innovation`：请求仅需 `major`、`grade`、`skills`。返回的 `schedule` 包含自动计算的周期、建议工时、日期及依据；旧版传入的时间字段不会控制新计划。
- `tests/test_preparation.py`：自动排期、计划约束和模拟 DeepSeek 的集成测试。

画像统一保存在当前浏览器 localStorage 的 `jingxu-profile-v1`，每个竞赛共用；计划与勾选进度仍按竞赛 ID 独立保存。旧版画像会迁移，原计划不会删除。修改画像不会自动重写已生成计划，后续生成和对话使用最新保存的画像。对话只存在当前页面内存，换浏览器不会同步。重新生成前会确认替换，导出可备份。AI 接口会发送档案、近期对话，调整建议还会发送当前计划与完成情况；调整建议不会自动覆写计划。

## 数据范围与限制

- 资料核验日期：2026-10-09；子页时间节点附来源链接、年份和精度。首页使用独立的 `registration_reference` 字段展示往年报名月份，子页展示参考依据；不显示初赛、复赛、决赛或通知发布日期。
- “挑战杯”学术科技主体赛当前只有 2025 年参考节点，2026 年不套用专项赛日期；创业计划主体赛部分日程仍待核实。
- 电子设计竞赛明确标注山东赛区示例与模拟电子专题赛报到，不能当作全国所有赛项统一日程。蓝桥杯区分软件科目，并标注组委会通知的拟定日期。
- 报名月份不是固定规则。例如创新大赛2025年系统5月开放，2026年调整至8月；首页显示5—8月参考区间。校内报名引用高校往年样例，不代表全国统一月份。所有数据人工维护，非实时日历。
- Bilibili 链接是搜索入口，知网是文献入口，不是经过筛选的具体课程或论文。**本版没有自动爬虫，也没有定时采集或实时文献检索**；`/api/resources/search` 是实时调用必应公开 RSS 的即时搜索，结果未经核验。
- 模板按竞赛方向及系统排期安排，个性化适配分析由 DeepSeek 完成；暂不进行多竞赛智能排名或组队匹配。短周期模板只适合精简训练，不承诺完成正式参赛全部要求。
- 这是本地单用户原型，没有账号、数据库、限流或生产环境鉴权。若部署公网，需先增加身份验证、调用配额和服务端持久化。

## 关于学习资源搜索

`/api/resources/search` 调用的是必应公开 RSS，有两个已知限制，**搜不到结果通常不是程序坏了**：

- 该接口会限流。被限流时它不返回空，而是返回一整套与关键词无关的结果（实测搜“数学建模”返回过 10 条英雄联盟攻略，搜“算法”返回过 10 条 Windows 帮助页）。后端按关键词重叠度拦掉这类结果，所以页面显示“返回的结果与关键词无关，已全部过滤”，并给出外部搜索入口。
- 结果经过排序：教育与政府域名、MOOC、B站、知网、官方文档优先，万能内容站降权，同一站点最多 2 条。成功结果缓存 10 分钟。

结果一律未经人工核验。若要稳定可用，需改接正式搜索 API，或把该功能降级为纯外部搜索入口。

## 验证

```powershell
./.venv-local/Scripts/python.exe -m unittest discover -s tests -v
node tests/test_disciplines.cjs
node tests/test_frontend_chat.cjs
```

Python 测试 42 项，使用模拟上游，不消耗 DeepSeek 额度；真实模型联调需要配置有效密钥。两个 `.cjs` 测试需要 Node.js，不装 Node 可跳过。
